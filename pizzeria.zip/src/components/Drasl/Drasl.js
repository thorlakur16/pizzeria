import React from 'react';

class Drasl extends React.Component {

    constructor () {
        super();
    }
    render () {


        return(
            <div className="Drasl">
                <img src='/images/pizza1.jpg' alt="logo" />
                <p>Síða fannst ekki.</p>
            </div>
        );
    }
}

export default Drasl;
import React, {Component} from 'react';
//import PropTypes from 'prop-types';

class About extends Component {
    render() {
        return (
            <div>
                <h2> About us </h2>
                <p> We make the best pizzas. 3 of our staff ate them and lived. In loving memory of Todd.</p>
            </div>
        );
    }
}

//MyComponent.propTypes = {};

export default About;
